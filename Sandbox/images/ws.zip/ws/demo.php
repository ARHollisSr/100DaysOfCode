#!/php -q
<?php

// Run from command prompt > php demo.php
require_once("websocket.server.php");

/**
 * This demo resource handler will respond to all messages sent to /echo/ on the socketserver below
 *
 * All this handler does is echoing the responds to the user
 * @author Chris
 *
 */
class DemoEchoHandler extends WebSocketUriHandler{
	public function onMessage(IWebSocketConnection $user, IWebSocketMessage $msg){
		$this->say("[ECHO] ".strlen($msg->getData()). " bytes");
		// Echo
		$user->sendMessage($msg);
	}

	public function onAdminMessage(IWebSocketConnection $user, IWebSocketMessage $obj){
		$this->say("[DEMO] Admin TEST received!");

		$frame = WebSocketFrame::create(WebSocketOpcode::PongFrame);
		$user->sendFrame($frame);
	}
}

/**
 * Demo socket server. Implements the basic eventlisteners and attaches a resource handler for /echo/ urls.
 *
 *
 * @author Chris
 *
 */
class DemoSocketServer implements IWebSocketServerObserver{
	protected $debug = true;
	protected $server;

	public function __construct(){
		$this->server = new WebSocketServer("tcp://0.0.0.0:12345", 'superdupersecretkey');
		$this->server->addObserver($this);

		$this->server->addUriHandler("echo", new DemoEchoHandler());
	}

	public function onConnect(IWebSocketConnection $user){
		$this->say("[DEMO] {$user->getId()} connected");
	}

	public function onMessage(IWebSocketConnection $user, IWebSocketMessage $msg){
		$msg = trim($msg->getData());
    switch($msg){
      case 'hello':
        $msgback = WebSocketMessage::create("hello human");
        $user->sendMessage($msgback);
        break;
      case 'name':
        $msgback = WebSocketMessage::create("I don't have a name");
        $user->sendMessage($msgback);
        break;
      case 'age':
        $msgback = WebSocketMessage::create("I'm old");
        $user->sendMessage($msgback);
        break;
      case 'date':
        $msgback = WebSocketMessage::create("today is ".date("F j, Y"));
        $user->sendMessage($msgback);
        break;
      case 'time':
        $msgback = WebSocketMessage::create("the time is ".date("H:iA"));
        $user->sendMessage($msgback);
        break;
      case 'thanks':
        $msgback = WebSocketMessage::create("you're welcome");
        $user->sendMessage($msgback);
        break;
      case 'bye':
        $msgback = WebSocketMessage::create("have a nice day");
        $user->sendMessage($msgback);
        break;
      default:
        $msgback = WebSocketMessage::create("I don't understand");
        $user->sendMessage($msgback);
        break;
    }
	}

	public function onDisconnect(IWebSocketConnection $user){
		$this->say("[DEMO] {$user->getId()} disconnected");
	}

	public function onAdminMessage(IWebSocketConnection $user, IWebSocketMessage $msg){
		$this->say("[DEMO] Admin Message received!");

		$frame = WebSocketFrame::create(WebSocketOpcode::PongFrame);
		$user->sendFrame($frame);
	}

	public function say($msg){
		echo "$msg \r\n";
	}

	public function run(){
		$this->server->run();
	}
}

// Start server
$server = new DemoSocketServer();
$server->run();
