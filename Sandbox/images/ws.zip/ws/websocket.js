function initiate(){
  databox=document.getElementById('databox');
  var button=document.getElementById('button');
  button.addEventListener('click', send, false);

  socket=new WebSocket("ws://www.minkbooks.com:12345/ws/server.php"); // CHANGE!!!
  socket.addEventListener('open', opened, false);
  socket.addEventListener('message', received, false);
  socket.addEventListener('close', closed, false);
  socket.addEventListener('error', error, false);
}
function opened(){
  databox.innerHTML='CONNECTION OPENED<br>';
  databox.innerHTML+='Status: '+socket.readyState;
}
function received(e){
  var list=databox.innerHTML;
  databox.innerHTML='Received: '+e.data+'<br>'+list;
}
function closed(){
  var list=databox.innerHTML;
  databox.innerHTML='CONNECTION CLOSED<br>'+list;

  var button=document.getElementById('button');
  button.disabled=true;
}
function error(){
  var list=databox.innerHTML;
  databox.innerHTML='ERROR<br>'+list;
}
function send(){
  var command=document.getElementById('command').value;
  if(command=='close'){
    socket.close();
  }else{
    socket.send(command);
  }
}
window.addEventListener('load', initiate, false);